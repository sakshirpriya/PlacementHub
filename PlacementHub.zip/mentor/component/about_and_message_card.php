
  <div style="border: 1px solid grey;" class="shadow-lg mb-5 bg-white rounded"> <button type="button" style="width: 100%;" class="btn btn-success btn-sm" style="margin-top: -30px;">About Me</button>
    <h5 style="padding: 5px;"><?php echo $row["about"]; ?> </h5>
  </div>
  <div style="border: 1px solid grey;" class="shadow-lg mb-5 bg-white rounded"> <button type="button" style="width: 100%;" class="btn btn-success btn-sm" style="margin-top: -30px;">Message for Student</button>
    <h5 style="padding: 5px;"><?php echo $row["message_for_student"]; ?></h5>
  </div>
